
Copyright (c) 2012-2015 Wombatica Software, All Rights Reserved

Uses OpenCV library under the 3-clause BSD license. See OpenCV_license.txt

Uses libexif library under LGPL license (http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html). Source code in http://wombatica.com/3rdparty/libexif-0.6.21.tar.bz2
